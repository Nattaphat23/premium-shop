# Premium Shop — Deploy Ready

## Run locally
```bash
npm install
npm start
```
Then open http://localhost:3000

## Default admin
- Email: admin@local
- Password: 1234

Change the admin password before real use.

## Deploy
This project is a Node.js/Express app. Upload the **contents of this folder** to a Git repository (not only the ZIP file), then deploy the repository as a Node.js web service.
- Build command: `npm install`
- Start command: `npm start`

The server listens on `process.env.PORT` and falls back to 3000 locally.
