const express=require('express');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const app=express();
app.use(express.json({limit:'8mb'}));
app.use(express.static(path.join(__dirname,'public')));

const DATA_DIR=path.join(__dirname,'data');
const DB=path.join(DATA_DIR,'db.json');
fs.mkdirSync(DATA_DIR,{recursive:true});
const seed={
 users:[{id:'admin',name:'Admin',email:'admin@local',passwordHash:hash('1234'),role:'admin'}],
 products:[
  {id:'nf',name:'Netflix Premium',icon:'🎬',duration:'30 วัน',price:99},
  {id:'yt',name:'YouTube Premium',icon:'▶️',duration:'30 วัน',price:59},
  {id:'cp',name:'CapCut Pro',icon:'✂️',duration:'30 วัน',price:49},
  {id:'viu',name:'Viu Premium',icon:'💜',duration:'30 วัน',price:30}
 ],
 orders:[],payments:[],stock:[],settings:{qrImage:'',promptpay:''}
};
function hash(s){return crypto.createHash('sha256').update(String(s)).digest('hex')}
function read(){if(!fs.existsSync(DB))fs.writeFileSync(DB,JSON.stringify(seed,null,2));return JSON.parse(fs.readFileSync(DB))}
function write(d){fs.writeFileSync(DB,JSON.stringify(d,null,2))}
function id(){return crypto.randomBytes(5).toString('hex')}
function auth(req,res,next){const t=req.headers.authorization?.replace('Bearer ','');const db=read();const u=db.users.find(x=>x.token===t);if(!u)return res.status(401).json({error:'กรุณาเข้าสู่ระบบ'});req.user=u;next()}
function admin(req,res,next){auth(req,res,()=>req.user.role==='admin'?next():res.status(403).json({error:'ไม่มีสิทธิ์'}) )}

app.get('/api/products',(req,res)=>{const db=read();res.json({products:db.products})});
app.get('/api/settings',(req,res)=>{res.json({settings:read().settings})});
app.post('/api/register',(req,res)=>{const {name,email,password}=req.body;if(!name||!email||!password)return res.status(400).json({error:'กรอกข้อมูลให้ครบ'});const db=read();if(db.users.some(u=>u.email===email))return res.status(400).json({error:'Email นี้มีบัญชีแล้ว'});const u={id:id(),name,email,passwordHash:hash(password),role:'user',token:crypto.randomBytes(24).toString('hex')};db.users.push(u);write(db);res.json({token:u.token,user:{id:u.id,name:u.name,email:u.email}})});
app.post('/api/login',(req,res)=>{const {email,password}=req.body;const db=read();const u=db.users.find(x=>x.email===email&&x.passwordHash===hash(password));if(!u)return res.status(401).json({error:'Email หรือ Password ไม่ถูกต้อง'});u.token=crypto.randomBytes(24).toString('hex');write(db);res.json({token:u.token,user:{id:u.id,name:u.name,email:u.email,role:u.role}})});
app.post('/api/orders',auth,(req,res)=>{const db=read();const items=(req.body.items||[]).map(x=>{const p=db.products.find(p=>p.id===x.productId);return p?{productId:p.id,name:p.name,price:p.price,qty:Math.max(1,Number(x.qty)||1)}:null}).filter(Boolean);if(!items.length)return res.status(400).json({error:'ไม่มีสินค้า'});const total=items.reduce((s,x)=>s+x.price*x.qty,0);const o={id:id(),userId:req.user.id,items,total,status:'awaiting_payment',credentials:[]};db.orders.push(o);write(db);res.json({order:o})});
app.get('/api/orders',auth,(req,res)=>{const db=read();res.json({orders:db.orders.filter(o=>o.userId===req.user.id).map(o=>({...o,payment:db.payments.find(p=>p.orderId===o.id)}))})});
app.post('/api/order-payment',auth,(req,res)=>{const {orderId,slip,slipName}=req.body;const db=read();const o=db.orders.find(x=>x.id===orderId&&x.userId===req.user.id);if(!o)return res.status(404).json({error:'ไม่พบออเดอร์'});if(!slip||!slip.startsWith('data:image/'))return res.status(400).json({error:'สลิปไม่ถูกต้อง'});db.payments=db.payments.filter(p=>p.orderId!==orderId);db.payments.push({orderId,slip,slipName,status:'pending',createdAt:new Date().toISOString()});o.status='payment_pending';write(db);res.json({ok:true})});

app.get('/api/admin/stats',admin,(req,res)=>{const db=read();res.json({users:db.users.filter(u=>u.role!=='admin').length,sales:db.orders.filter(o=>o.status==='paid'||o.status==='completed').reduce((s,o)=>s+o.total,0),stock:db.stock.filter(s=>!s.used).length,pending:db.orders.filter(o=>o.status==='payment_pending').length})});
app.get('/api/admin/topups',admin,(req,res)=>res.json({topups:[]}));
app.get('/api/admin/orders',admin,(req,res)=>{const db=read();res.json({orders:db.orders.map(o=>({...o,payment:db.payments.find(p=>p.orderId===o.id)||null}))})});
app.get('/api/admin/stock',admin,(req,res)=>res.json({stock:read().stock}));
app.post('/api/admin/orders/payment-approve',admin,(req,res)=>{const db=read();const o=db.orders.find(x=>x.id===req.body.id);if(!o)return res.status(404).json({error:'ไม่พบออเดอร์'});const p=db.payments.find(x=>x.orderId===o.id);if(!p)return res.status(400).json({error:'ไม่มีสลิป'});const paid=Number(req.body.paidAmount);if(paid!==Number(o.total))return res.status(400).json({error:'ยอดเงินไม่ตรงยอดออเดอร์'});p.status='approved';o.status='paid';write(db);res.json({ok:true})});
app.post('/api/admin/orders/payment-reject',admin,(req,res)=>{const db=read();const o=db.orders.find(x=>x.id===req.body.id);const p=db.payments.find(x=>x.orderId===req.body.id);if(!o||!p)return res.status(404).json({error:'ไม่พบข้อมูล'});p.status='rejected';o.status='payment_rejected';write(db);res.json({ok:true})});
app.post('/api/admin/stock',admin,(req,res)=>{const {productId,email,password,pin,expires}=req.body;if(!productId||!email||!password)return res.status(400).json({error:'กรอก Stock ให้ครบ'});const db=read();db.stock.push({id:id(),productId,email,password,pin,expires,used:false});write(db);res.json({ok:true})});
app.post('/api/admin/dispatch',admin,(req,res)=>{const db=read();const o=db.orders.find(x=>x.id===req.body.orderId);const s=db.stock.find(x=>x.id===req.body.stockId&&!x.used);if(!o||!s)return res.status(400).json({error:'เลือกออเดอร์หรือ Stock ไม่ถูกต้อง'});if(o.status!=='paid')return res.status(400).json({error:'ต้องอนุมัติการชำระเงินก่อน'});s.used=true;o.credentials.push({email:s.email,password:s.password,pin:s.pin,expires:s.expires});o.status='completed';write(db);res.json({ok:true})});
app.post('/api/admin/qr',admin,(req,res)=>{const db=read();db.settings.qrImage=req.body.qrImage||'';db.settings.promptpay=req.body.promptpay||'';write(db);res.json({ok:true})});

app.get('*splat',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log('Premium shop running on '+port));
